from flask import Flask, request, jsonify
from flask_cors import CORS
import jwt
from datetime import datetime, timedelta
import os
from functools import wraps

app = Flask(__name__)

# Configuração CORS - permite requisições do frontend no Firebase
CORS(app, origins=["https://anoteaqui-44325.web.app", "http://localhost:3000"])

# Chave secreta para JWT
app.config['SECRET_KEY'] = os.getenv('SECRET_KEY', 'noteaqui-super-secret-key-2024')

# Simulação de banco de dados em memória
users_db = {}
events_db = {}
user_id_counter = 1
event_id_counter = 1

# Decorator para verificar autenticação
def token_required(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        token = request.headers.get('Authorization')
        
        if not token:
            return jsonify({'message': 'Token não fornecido'}), 401
        
        try:
            # Remove "Bearer " do token
            token = token.replace('Bearer ', '')
            # Decodifica o token
            payload = jwt.decode(token, app.config['SECRET_KEY'], algorithms=['HS256'])
            request.user_id = payload['user_id']
            request.user_email = payload['email']
        except jwt.ExpiredSignatureError:
            return jsonify({'message': 'Token expirado'}), 401
        except jwt.InvalidTokenError:
            return jsonify({'message': 'Token inválido'}), 401
        
        return f(*args, **kwargs)
    
    return decorated

# ============= ROTAS DE TESTE =============

@app.route('/')
def home():
    return jsonify({
        'message': 'NoteAqui Backend ativo!',
        'version': '1.0.0',
        'status': 'online'
    })

@app.route('/api/test', methods=['GET'])
def test_connection():
    return jsonify({
        'status': 'success',
        'message': 'Backend NoteAqui funcionando!',
        'timestamp': datetime.now().isoformat()
    })

# ============= ROTAS DE AUTENTICAÇÃO =============

@app.route('/api/auth/register', methods=['POST'])
def register():
    global user_id_counter
    try:
        data = request.get_json()
        
        # Validação básica
        if not data.get('email') or not data.get('password') or not data.get('name'):
            return jsonify({'message': 'Dados obrigatórios faltando'}), 400
        
        email = data['email']
        
        # Verifica se o usuário já existe
        if email in users_db:
            return jsonify({'message': 'Email já cadastrado'}), 400
        
        # Cria novo usuário
        user_id = user_id_counter
        user_id_counter += 1
        
        users_db[email] = {
            'id': user_id,
            'name': data['name'],
            'email': email,
            'password': data['password'],  # Em produção, use hash!
            'bio': '',
            'phone': '',
            'location': '',
            'timezone': 'America/Sao_Paulo'
        }
        
        # Gerar token JWT
        token = jwt.encode({
            'user_id': user_id,
            'email': email,
            'exp': datetime.utcnow() + timedelta(days=30)
        }, app.config['SECRET_KEY'], algorithm='HS256')
        
        return jsonify({
            'success': True,
            'token': token,
            'user': {
                'id': user_id,
                'name': data['name'],
                'email': email
            }
        })
        
    except Exception as e:
        return jsonify({'message': f'Erro interno do servidor: {str(e)}'}), 500

@app.route('/api/auth/login', methods=['POST'])
def login():
    try:
        data = request.get_json()
        
        # Validação básica
        if not data.get('email') or not data.get('password'):
            return jsonify({'message': 'Email e senha são obrigatórios'}), 400
        
        email = data['email']
        password = data['password']
        
        # Verifica se o usuário existe
        user = users_db.get(email)
        
        if not user or user['password'] != password:
            return jsonify({'message': 'Email ou senha inválidos'}), 401
        
        # Gerar token JWT
        token = jwt.encode({
            'user_id': user['id'],
            'email': email,
            'exp': datetime.utcnow() + timedelta(days=30)
        }, app.config['SECRET_KEY'], algorithm='HS256')
        
        return jsonify({
            'success': True,
            'token': token,
            'user': {
                'id': user['id'],
                'name': user['name'],
                'email': user['email']
            }
        })
        
    except Exception as e:
        return jsonify({'message': f'Erro interno do servidor: {str(e)}'}), 500

@app.route('/api/auth/validate', methods=['GET'])
def validate_token():
    try:
        token = request.headers.get('Authorization')
        if not token:
            return jsonify({'message': 'Token não fornecido'}), 401
        
        # Remove "Bearer " do token
        token = token.replace('Bearer ', '')
        
        # Decodifica o token
        payload = jwt.decode(token, app.config['SECRET_KEY'], algorithms=['HS256'])
        
        # Busca informações do usuário
        user_email = payload['email']
        user = users_db.get(user_email, {})
        
        return jsonify({
            'user': {
                'id': payload['user_id'],
                'email': user_email,
                'name': user.get('name', 'Usuário')
            }
        })
        
    except jwt.ExpiredSignatureError:
        return jsonify({'message': 'Token expirado'}), 401
    except jwt.InvalidTokenError:
        return jsonify({'message': 'Token inválido'}), 401

# ============= ROTAS DE EVENTOS =============

@app.route('/api/events', methods=['GET'])
@token_required
def get_events():
    try:
        user_id = request.user_id
        
        # Filtra eventos do usuário
        user_events = [event for event in events_db.values() if event['user_id'] == user_id]
        
        # Parâmetros de filtro
        start_date = request.args.get('start_date')
        end_date = request.args.get('end_date')
        
        if start_date:
            user_events = [e for e in user_events if e['date'] >= start_date]
        if end_date:
            user_events = [e for e in user_events if e['date'] <= end_date]
        
        return jsonify({
            'success': True,
            'events': user_events
        })
        
    except Exception as e:
        return jsonify({'message': f'Erro interno do servidor: {str(e)}'}), 500

@app.route('/api/events', methods=['POST'])
@token_required
def create_event():
    global event_id_counter
    try:
        user_id = request.user_id
        data = request.get_json()
        
        # Validação básica
        if not data.get('title') or not data.get('date'):
            return jsonify({'message': 'Título e data são obrigatórios'}), 400
        
        # Cria novo evento
        event_id = event_id_counter
        event_id_counter += 1
        
        new_event = {
            'id': event_id,
            'user_id': user_id,
            'title': data['title'],
            'description': data.get('description', ''),
            'date': data['date'],
            'time': data.get('time', '00:00'),
            'location': data.get('location', ''),
            'type': data.get('type', 'event'),
            'priority': data.get('priority', 'medium'),
            'created_at': datetime.now().isoformat()
        }
        
        events_db[event_id] = new_event
        
        return jsonify({
            'success': True,
            'event': new_event
        }), 201
        
    except Exception as e:
        return jsonify({'message': f'Erro interno do servidor: {str(e)}'}), 500

@app.route('/api/events/<int:event_id>', methods=['GET'])
@token_required
def get_event(event_id):
    try:
        user_id = request.user_id
        event = events_db.get(event_id)
        
        if not event:
            return jsonify({'message': 'Evento não encontrado'}), 404
        
        if event['user_id'] != user_id:
            return jsonify({'message': 'Acesso negado'}), 403
        
        return jsonify({
            'success': True,
            'event': event
        })
        
    except Exception as e:
        return jsonify({'message': f'Erro interno do servidor: {str(e)}'}), 500

@app.route('/api/events/<int:event_id>', methods=['PUT'])
@token_required
def update_event(event_id):
    try:
        user_id = request.user_id
        event = events_db.get(event_id)
        
        if not event:
            return jsonify({'message': 'Evento não encontrado'}), 404
        
        if event['user_id'] != user_id:
            return jsonify({'message': 'Acesso negado'}), 403
        
        data = request.get_json()
        
        # Atualiza campos
        event['title'] = data.get('title', event['title'])
        event['description'] = data.get('description', event['description'])
        event['date'] = data.get('date', event['date'])
        event['time'] = data.get('time', event['time'])
        event['location'] = data.get('location', event['location'])
        event['type'] = data.get('type', event['type'])
        event['priority'] = data.get('priority', event['priority'])
        event['updated_at'] = datetime.now().isoformat()
        
        return jsonify({
            'success': True,
            'event': event
        })
        
    except Exception as e:
        return jsonify({'message': f'Erro interno do servidor: {str(e)}'}), 500

@app.route('/api/events/<int:event_id>', methods=['DELETE'])
@token_required
def delete_event(event_id):
    try:
        user_id = request.user_id
        event = events_db.get(event_id)
        
        if not event:
            return jsonify({'message': 'Evento não encontrado'}), 404
        
        if event['user_id'] != user_id:
            return jsonify({'message': 'Acesso negado'}), 403
        
        del events_db[event_id]
        
        return jsonify({
            'success': True,
            'message': 'Evento deletado com sucesso'
        })
        
    except Exception as e:
        return jsonify({'message': f'Erro interno do servidor: {str(e)}'}), 500

@app.route('/api/events/search', methods=['GET'])
@token_required
def search_events():
    try:
        user_id = request.user_id
        query = request.args.get('q', '').lower()
        
        # Filtra eventos do usuário
        user_events = [event for event in events_db.values() if event['user_id'] == user_id]
        
        # Busca por título ou descrição
        if query:
            user_events = [
                e for e in user_events 
                if query in e['title'].lower() or query in e['description'].lower()
            ]
        
        return jsonify({
            'success': True,
            'events': user_events
        })
        
    except Exception as e:
        return jsonify({'message': f'Erro interno do servidor: {str(e)}'}), 500

# ============= ROTAS DE PERFIL =============

@app.route('/api/user/profile', methods=['GET'])
@token_required
def get_profile():
    try:
        user_email = request.user_email
        user = users_db.get(user_email)
        
        if not user:
            return jsonify({'message': 'Usuário não encontrado'}), 404
        
        user_profile = {
            'id': user['id'],
            'name': user['name'],
            'email': user['email'],
            'bio': user.get('bio', ''),
            'phone': user.get('phone', ''),
            'location': user.get('location', ''),
            'timezone': user.get('timezone', 'America/Sao_Paulo')
        }
        
        return jsonify({
            'success': True,
            'user': user_profile
        })
        
    except Exception as e:
        return jsonify({'message': f'Erro interno do servidor: {str(e)}'}), 500

@app.route('/api/user/profile', methods=['PUT'])
@token_required
def update_profile():
    try:
        user_email = request.user_email
        user = users_db.get(user_email)
        
        if not user:
            return jsonify({'message': 'Usuário não encontrado'}), 404
        
        data = request.get_json()
        
        # Atualiza campos
        if 'name' in data:
            user['name'] = data['name']
        if 'bio' in data:
            user['bio'] = data['bio']
        if 'phone' in data:
            user['phone'] = data['phone']
        if 'location' in data:
            user['location'] = data['location']
        if 'timezone' in data:
            user['timezone'] = data['timezone']
        
        return jsonify({
            'success': True,
            'message': 'Perfil atualizado com sucesso',
            'user': {
                'id': user['id'],
                'name': user['name'],
                'email': user['email'],
                'bio': user['bio'],
                'phone': user['phone'],
                'location': user['location'],
                'timezone': user['timezone']
            }
        })
        
    except Exception as e:
        return jsonify({'message': f'Erro interno do servidor: {str(e)}'}), 500

# ============= TRATAMENTO DE ERROS =============

@app.errorhandler(404)
def not_found(error):
    return jsonify({'message': 'Rota não encontrada'}), 404

@app.errorhandler(500)
def internal_error(error):
    return jsonify({'message': 'Erro interno do servidor'}), 500

# ============= EXECUÇÃO =============

if __name__ == '__main__':
    port = int(os.environ.get('PORT', 5000))
    app.run(debug=False, host='0.0.0.0', port=port)
